# Product Requirements Document (PRD)
## Khallak Nabeeh — AI-Powered Online Scam Detection Platform

**Version:** 1.0  
**Last Updated:** July 2026  
**Status:** Active Development  
**Target Audience:** Arabic-speaking users across MENA region

---

## 1. Executive Summary

**Khallak Nabeeh** (خلك نبيه) is an intelligent, AI-powered platform designed to detect and analyze online scams in real-time. Users can submit suspicious text messages, emails, and links for instant analysis, receiving a risk assessment with threat classification and actionable recommendations. The platform combines natural language processing, pattern recognition, and machine learning to protect Arabic-speaking users from digital fraud.

**Mission:** Empower everyday users to identify and avoid online scams before falling victim to fraud.

**Vision:** Build the most trusted cybersecurity companion for the Arabic-speaking world.

---

## 2. Problem Statement

### Current Challenges
- **Rising Fraud Rates:** Online scams in the MENA region increased 340% between 2020-2023
- **Language Barrier:** Most anti-fraud tools are English-only, missing Arabic-specific scam patterns
- **User Awareness Gap:** 1 in 3 Arabic-speaking users have fallen victim to online fraud
- **Complexity:** Existing solutions require technical knowledge; average users struggle to identify threats
- **No Localized Solution:** No dedicated platform addresses Arabic scam detection with cultural context

### Target Problem
Users need a **simple, instant, Arabic-native tool** to verify suspicious messages before engaging with them.

---

## 3. Product Vision & Goals

### Primary Goals (Phase 1)
1. Provide instant scam detection for text messages, emails, and links
2. Deliver risk assessment with clear threat classification
3. Educate users on fraud prevention best practices
4. Build trust through transparency and accuracy

### Secondary Goals (Phase 2-3)
1. Build user community with reporting and feedback mechanisms
2. Establish B2B partnerships with telecom and financial institutions
3. Create API for third-party integrations
4. Develop mobile app for iOS and Android

### Success Metrics
- **Accuracy:** ≥95% scam detection rate
- **User Engagement:** 10K+ daily active users within 6 months
- **Retention:** 40%+ 30-day retention rate
- **Trust:** 4.5+ star rating on app stores

---

## 4. Target Users & Personas

### Primary User: Cautious Consumer (Age 25-55)
- **Characteristics:** Receives frequent suspicious messages, wants verification before acting
- **Pain Point:** Unsure if messages are legitimate; fears losing money or personal data
- **Behavior:** Uses WhatsApp, email, SMS regularly; tech-savvy enough to use web apps
- **Goal:** Quick, reliable scam detection without technical jargon

### Secondary User: Cybersecurity Advocate (Age 20-40)
- **Characteristics:** Wants to protect family and community; interested in fraud statistics
- **Pain Point:** Limited tools to educate others; no centralized reporting mechanism
- **Behavior:** Shares security tips; reports scams to authorities
- **Goal:** Access to analytics, reporting tools, and educational content

### Tertiary User: Enterprise/Institution (B2B)
- **Characteristics:** Banks, telecom companies, government agencies
- **Pain Point:** Need to protect customers at scale; require API integration
- **Behavior:** Integrates third-party security tools into their systems
- **Goal:** Bulk analysis, API access, white-label solutions

---

## 5. Core Features (MVP - Phase 1)

### 5.1 Scam Analysis Engine
**Description:** Real-time AI analysis of user-submitted content

**Functionality:**
- Accept three content types: SMS/Text Messages, Emails, URLs/Links
- Analyze content against 50+ known scam patterns
- Return risk score (0-100%) with three-tier classification: Safe, Caution, Danger
- Identify threat type: Phishing, Prize Scam, Investment Fraud, Identity Theft, Malicious Link, Social Engineering, etc.
- Provide detailed analysis breakdown with specific red flags detected
- Display recommendations based on risk level

**Technical Requirements:**
- Process analysis within 3 seconds
- Support Arabic text analysis with NLP
- Pattern matching against fraud database
- Machine learning model for pattern detection

### 5.2 User Interface
**Description:** Intuitive, Arabic-native RTL interface

**Components:**
- Hero section with value proposition
- Content type selector (Message/Email/Link)
- Text input area with character counter
- Analysis button with loading state
- Results card with risk visualization
- Educational tips section
- Statistics dashboard
- Footer with reporting links

**Design System:**
- Dark navy primary color (oklch(0.18 0.04 255))
- Amber gold accent (oklch(0.78 0.16 75))
- Red for danger alerts (oklch(0.62 0.22 25))
- Green for safe indicators (oklch(0.65 0.18 145))
- Full RTL support with Arabic typography

### 5.3 Educational Content
**Description:** Security awareness and fraud prevention tips

**Content Areas:**
- "How It Works" section explaining the analysis process
- Security tips with priority levels
- Statistics on fraud trends in MENA region
- Links to official reporting channels (Kulluna Amn)
- FAQ section addressing common questions

### 5.4 Results Display
**Description:** Clear, actionable analysis results

**Information Provided:**
- Risk Level Badge (Safe/Caution/Danger)
- Risk Score Percentage (0-100%)
- Threat Type Classification
- Detailed Analysis Breakdown (3-5 specific red flags)
- Recommendation Message
- High-Risk Alert: "If you believe this is fraud, report it via Kulluna Amn"

---

## 6. Future Features (Phase 2-3)

### Phase 2: User Accounts & Analytics (Months 4-6)

#### 6.1 User Authentication
- Email/phone registration with OTP verification
- Social login (Google, Apple)
- Password management and account recovery
- Two-factor authentication (2FA) option

#### 6.2 User Dashboard
- Analysis history with timestamps
- Statistics: Total analyses, threats detected, risk distribution
- Saved analyses for reference
- Personal threat profile (most common threat types)
- Export analysis history as PDF/CSV

#### 6.3 Reporting & Feedback
- Report false positives/negatives to improve AI
- Flag specific analyses as helpful/unhelpful
- Submit new scam patterns for database
- Community voting on analysis accuracy

### Phase 3: Monetization & B2B (Months 7-12)

#### 6.4 Subscription Tiers

**Free Tier:**
- 5 analyses per day
- Basic threat detection
- No history storage
- Community access

**Pro Tier ($4.99/month):**
- Unlimited analyses
- Advanced threat intelligence
- Full history storage (12 months)
- Priority support
- Export capabilities

**Enterprise Tier (Custom Pricing):**
- Bulk API access (10K+ analyses/month)
- White-label solution
- Custom threat database
- Dedicated support
- SLA guarantee (99.9% uptime)

#### 6.5 API for Third Parties
- REST API for scam analysis
- Webhook support for real-time notifications
- Rate limiting and quota management
- API documentation and SDKs (Python, JavaScript, PHP)
- Authentication via API keys

**Use Cases:**
- Telecom companies: Analyze SMS before delivery
- Banks: Screen emails for phishing
- E-commerce: Verify user-submitted links
- Government agencies: Bulk fraud detection

#### 6.6 Mobile Applications
- iOS app (React Native/Swift)
- Android app (React Native/Kotlin)
- Offline mode for basic pattern matching
- Push notifications for security alerts
- Share analysis via messaging apps

---

## 7. Technical Architecture

### 7.1 Frontend Stack
- **Framework:** React 19 + TypeScript
- **Styling:** Tailwind CSS 4 with custom theme
- **UI Components:** shadcn/ui with RTL support
- **State Management:** React Context API
- **Routing:** Wouter for client-side routing
- **Animations:** Framer Motion for micro-interactions

### 7.2 Backend Stack (Future)
- **Runtime:** Node.js with Express
- **Database:** PostgreSQL for user data, MongoDB for analysis logs
- **AI/ML:** Python with scikit-learn, TensorFlow for pattern detection
- **API:** RESTful API with OpenAPI documentation
- **Authentication:** JWT tokens with refresh mechanism
- **Caching:** Redis for frequently accessed data

### 7.3 AI/ML Pipeline
- **NLP Model:** Arabic-specific language model (e.g., AraBERT)
- **Pattern Database:** 500+ known scam patterns (SMS, email, URL)
- **Scoring Algorithm:** Weighted pattern matching + ML classifier
- **Feedback Loop:** User corrections improve model accuracy
- **Update Frequency:** Weekly model updates with new patterns

### 7.4 Infrastructure
- **Hosting:** Cloud platform (AWS/GCP/Azure)
- **CDN:** Global content delivery for fast load times
- **Security:** HTTPS, WAF, DDoS protection
- **Monitoring:** Real-time error tracking, performance monitoring
- **Backup:** Daily automated backups with disaster recovery

---

## 8. User Flows

### 8.1 Core User Flow: Scam Analysis
```
1. User lands on homepage
2. Selects content type (Message/Email/Link)
3. Pastes suspicious content
4. Clicks "Analyze Now" button
5. System analyzes content (2-3 seconds)
6. Results displayed with risk level, score, threat type
7. User reads recommendations
8. Optional: User reports as helpful/unhelpful
9. Optional: User shares result or exports
```

### 8.2 Registration Flow (Phase 2)
```
1. User clicks "Sign Up"
2. Enters email or phone number
3. Receives OTP verification code
4. Verifies code
5. Creates password
6. Account created, dashboard accessible
7. Analysis history begins tracking
```

### 8.3 API Integration Flow (Phase 3)
```
1. Enterprise client requests API access
2. Khallak Nabeeh team reviews and approves
3. Client receives API key
4. Client integrates API into their system
5. Client sends analysis requests to API
6. API returns risk assessment in JSON format
7. Client displays results to their users
```

---

## 9. Monetization Strategy

### Revenue Streams

**1. Freemium Model (Primary)**
- Free tier with limited analyses (5/day)
- Pro tier at $4.99/month for power users
- Target: 5% conversion rate = $25K MRR at 100K users

**2. B2B API Licensing**
- Starter: $499/month (10K analyses)
- Professional: $1,999/month (100K analyses)
- Enterprise: Custom pricing (1M+ analyses)
- Target: 50 enterprise clients = $100K MRR

**3. White-Label Solutions**
- Custom branding for banks/telecom
- Pricing: $5K-$50K per implementation
- Target: 10 clients in Year 1 = $150K revenue

**4. Data Insights & Reports**
- Quarterly fraud trend reports for enterprises
- Pricing: $1K-$5K per report
- Target: 20 reports/quarter = $20K revenue

**Total Year 1 Projection:** $500K-$1M revenue

---

## 10. Competitive Analysis

### Competitors
| Competitor | Strengths | Weaknesses | Khallak Nabeeh Advantage |
|---|---|---|---|
| **Phishing Simulator** | Enterprise-focused | English-only, expensive | Arabic-native, free for consumers |
| **Kaspersky Safe** | Established brand | Complex UI, not RTL | Simple, Arabic-first design |
| **Scam Alert (Govt)** | Official authority | Limited scope, no AI | Real-time AI analysis |
| **WhatsApp Safety** | Built-in feature | Limited analysis | Dedicated, detailed reports |

**Key Differentiators:**
1. **Arabic-First:** Only platform designed for Arabic-speaking users
2. **Simplicity:** One-click analysis vs. complex security suites
3. **Community-Driven:** User feedback improves AI continuously
4. **Localization:** Understands cultural scam patterns in MENA
5. **Accessibility:** Free for consumers, affordable for enterprises

---

## 11. Go-to-Market Strategy

### Phase 1: Launch (Month 1-2)
- Soft launch to 1K beta users
- Gather feedback and iterate
- Optimize for accuracy and speed
- Build initial user base through word-of-mouth

### Phase 2: Growth (Month 3-6)
- Public launch with marketing campaign
- Partnerships with tech influencers in MENA
- PR outreach to cybersecurity media
- Community building on social media
- Target: 50K users

### Phase 3: Expansion (Month 7-12)
- Mobile app launch (iOS/Android)
- B2B partnerships with telecom/banks
- API launch for third-party integrations
- Expansion to additional languages (French, Urdu)
- Target: 500K users

### Marketing Channels
- **Social Media:** TikTok, Instagram, Twitter (Arabic content)
- **Influencers:** Cybersecurity experts, tech reviewers
- **Content Marketing:** Blog posts on scam prevention
- **Partnerships:** Telecom companies, banks, government agencies
- **PR:** Tech media coverage, security conferences
- **Organic:** SEO for scam-related keywords

---

## 12. Success Metrics & KPIs

### User Metrics
| KPI | Target (6 months) | Target (12 months) |
|---|---|---|
| Total Users | 100K | 500K |
| Daily Active Users | 10K | 50K |
| Monthly Active Users | 30K | 150K |
| 30-Day Retention | 40% | 50% |
| 90-Day Retention | 25% | 35% |

### Product Metrics
| KPI | Target |
|---|---|
| Analysis Accuracy | ≥95% |
| Average Analysis Time | <3 seconds |
| False Positive Rate | <5% |
| User Satisfaction | 4.5+ stars |
| Analysis Completion Rate | >90% |

### Business Metrics
| KPI | Target (12 months) |
|---|---|
| Free-to-Pro Conversion | 5% |
| Average Revenue Per User (ARPU) | $2.50/month |
| Customer Acquisition Cost (CAC) | <$1 |
| Lifetime Value (LTV) | $30 |
| LTV:CAC Ratio | >30:1 |

---

## 13. Risk Analysis & Mitigation

### Technical Risks
| Risk | Impact | Mitigation |
|---|---|---|
| AI Model Accuracy Drops | High | Continuous model retraining, user feedback loop |
| Scalability Issues | High | Cloud infrastructure with auto-scaling |
| Data Breach | Critical | Encryption, security audits, compliance (GDPR, PDPA) |
| API Downtime | High | 99.9% SLA, redundant infrastructure |

### Market Risks
| Risk | Impact | Mitigation |
|---|---|---|
| Low User Adoption | High | Strong marketing, partnerships, influencer campaigns |
| Competitor Entry | Medium | First-mover advantage, community lock-in |
| Regulatory Changes | Medium | Legal compliance team, proactive policy engagement |
| Fraud Pattern Evolution | Medium | Continuous AI model updates, security research |

### Operational Risks
| Risk | Impact | Mitigation |
|---|---|---|
| Team Turnover | Medium | Competitive compensation, strong culture |
| Funding Shortage | High | Diversified revenue streams, investor relations |
| Reputation Damage | Critical | Transparent communication, rapid incident response |

---

## 14. Timeline & Milestones

### Phase 1: MVP Launch (Months 1-3)
- ✅ Core analysis engine (completed)
- ✅ Web interface (completed)
- ✅ Educational content (completed)
- [ ] Beta testing with 1K users
- [ ] Feedback collection and iteration
- [ ] Public launch announcement

### Phase 2: User Accounts & Growth (Months 4-6)
- [ ] User authentication system
- [ ] User dashboard and history
- [ ] Reporting and feedback mechanisms
- [ ] Mobile-responsive optimization
- [ ] Marketing campaign launch
- [ ] Target: 100K users

### Phase 3: Monetization & B2B (Months 7-12)
- [ ] Subscription tier implementation
- [ ] Payment processing integration
- [ ] API development and documentation
- [ ] B2B partnership agreements
- [ ] Mobile app launch (iOS/Android)
- [ ] Target: 500K users, $500K revenue

### Phase 4: Scale & Expansion (Year 2)
- [ ] Additional language support
- [ ] Advanced analytics dashboard
- [ ] White-label solutions
- [ ] International expansion
- [ ] Enterprise features

---

## 15. Resource Requirements

### Team Composition
- **Product Manager:** 1 (oversee roadmap, stakeholder management)
- **Backend Engineers:** 2 (API, database, infrastructure)
- **Frontend Engineers:** 2 (web and mobile UI)
- **ML Engineer:** 1 (AI model development, training)
- **DevOps Engineer:** 1 (infrastructure, monitoring)
- **QA/Tester:** 1 (testing, quality assurance)
- **Designer:** 1 (UI/UX, branding)
- **Marketing/Growth:** 1 (user acquisition, partnerships)
- **Total:** 10 people

### Budget Estimate (Year 1)
| Category | Amount |
|---|---|
| Salaries (10 people) | $400K |
| Infrastructure & Hosting | $50K |
| Tools & Software | $20K |
| Marketing & Partnerships | $80K |
| Legal & Compliance | $30K |
| Contingency (10%) | $58K |
| **Total** | **$638K** |

---

## 16. Success Criteria & Exit Strategy

### Success Criteria
- ✅ Launch MVP with 95%+ accuracy
- ✅ Achieve 100K users within 6 months
- ✅ Maintain 40%+ 30-day retention
- ✅ Secure Series A funding ($2-5M)
- ✅ Establish 10+ B2B partnerships
- ✅ Achieve profitability by Month 18

### Potential Exit Strategies
1. **Acquisition:** Cybersecurity firms (Norton, McAfee), Telecom giants (STC, Etisalat)
2. **IPO:** Public listing on regional stock exchange (Tadawul, DFM)
3. **Strategic Partnership:** Integration into larger security platforms
4. **Sustainable Business:** Profitable standalone company serving MENA region

---

## 17. Appendix

### A. Glossary
- **Phishing:** Fraudulent attempt to obtain sensitive information by impersonation
- **Scam Pattern:** Recurring characteristics of fraudulent messages
- **Risk Score:** Percentage likelihood that content is fraudulent (0-100%)
- **Threat Type:** Category of fraud (phishing, prize scam, etc.)
- **NLP:** Natural Language Processing for text analysis
- **ML:** Machine Learning for pattern recognition

### B. References
- NCSC (National Cybersecurity Center) Fraud Statistics 2023
- Kaspersky Security Report: MENA Region 2023
- Kulluna Amn Platform Documentation
- GDPR & PDPA Compliance Guidelines

### C. Revision History
| Version | Date | Author | Changes |
|---|---|---|---|
| 1.0 | July 2026 | Product Team | Initial PRD |

---

**Document Status:** APPROVED FOR DEVELOPMENT  
**Next Review:** October 2026  
**Contact:** product@khallaknabee.com
