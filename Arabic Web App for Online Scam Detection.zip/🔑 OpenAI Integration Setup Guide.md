# 🔑 OpenAI Integration Setup Guide
## Khallak Nabeeh — Real AI-Powered Scam Detection

**Quick Setup (5 minutes)**

---

## 📝 Step-by-Step Instructions

### Step 1: Get Your OpenAI API Key ✅

1. Go to **[platform.openai.com](https://platform.openai.com)**
2. Sign up or log in
3. Click **"API keys"** in the left sidebar
4. Click **"Create new secret key"**
5. Copy the key (format: `sk-proj-xxxxxxxx...`)
6. **Save it somewhere safe** — you won't see it again!

**Your API Key:**
```
sk-proj-[your-key-here]
```

---

### Step 2: Add API Key to Project ✅

#### Option A: Using Manus Platform (Recommended)

1. Open your project in Manus
2. Click **Settings** (⚙️) in the Management UI
3. Go to **Secrets**
4. Click **"Add Secret"**
5. Fill in:
   - **Key:** `VITE_OPENAI_API_KEY`
   - **Value:** `sk-proj-your-actual-key`
6. Click **"Save"**
7. **Restart the dev server:**
   ```bash
   pnpm run dev
   ```

#### Option B: Local Development

1. Create `.env.local` file in project root:
   ```bash
   touch .env.local
   ```

2. Add your API key:
   ```env
   VITE_OPENAI_API_KEY=sk-proj-your-actual-key
   ```

3. Save the file

4. Restart dev server:
   ```bash
   pnpm run dev
   ```

---

### Step 3: Enable Real AI Analysis ✅

The project is configured to automatically use OpenAI when the API key is available.

**How it works:**
- If API key is set → Uses real OpenAI GPT-4 Turbo
- If API key is missing → Falls back to mock analyzer

**To verify it's working:**

1. Open the app at `http://localhost:3000`
2. Paste a test message:
   ```
   مبروك! فزت بجائزة بقيمة 50,000 ريال. اضغط هنا للمطالبة بجائزتك
   ```
3. Click **"حلّل الآن"** (Analyze Now)
4. Wait 2-3 seconds for OpenAI response
5. You should see a detailed analysis with risk score

---

### Step 4: Monitor Your Usage ✅

1. Visit **[platform.openai.com/account/usage](https://platform.openai.com/account/usage/overview)**
2. Check your usage and costs
3. Set a **usage limit** to avoid surprises:
   - Go to **Billing → Usage limits**
   - Set a monthly limit (e.g., $10/month)

---

## 💰 Cost Breakdown

### Per-Analysis Cost
- **Input tokens:** ~200 (your message)
- **Output tokens:** ~100 (AI response)
- **Cost per analysis:** ~$0.005 (GPT-4 Turbo)

### Monthly Examples
| Users | Analyses | Cost |
|---|---|---|
| 100 | 5,000 | $25 |
| 1,000 | 50,000 | $250 |
| 10,000 | 500,000 | $2,500 |

### Cost Optimization
- Use GPT-4o instead (3x cheaper): $0.0015/analysis
- Implement caching for repeated queries
- Monitor usage weekly

---

## ✅ Verification Checklist

- [ ] OpenAI account created
- [ ] API key generated
- [ ] API key added to project
- [ ] Dev server restarted
- [ ] Test analysis completed successfully
- [ ] Usage limits set in OpenAI dashboard
- [ ] Budget confirmed and acceptable

---

## 🐛 Troubleshooting

### Problem: "API key not configured"

**Solution:**
```bash
# Check if key is set
echo $VITE_OPENAI_API_KEY

# If empty, add it to .env.local
# Then restart:
pnpm run dev
```

### Problem: "Invalid API Key"

**Solution:**
1. Verify key starts with `sk-proj-`
2. Check for extra spaces or characters
3. Regenerate key if needed:
   - Visit [API Keys](https://platform.openai.com/api-keys)
   - Delete old key
   - Create new key

### Problem: "Rate limit exceeded"

**Solution:**
- Wait a few minutes
- Check your usage limits
- Upgrade your OpenAI plan for higher limits

### Problem: "Timeout after 30 seconds"

**Solution:**
- Check internet connection
- Try again (OpenAI might be slow)
- Check OpenAI status: [status.openai.com](https://status.openai.com)

### Problem: Still using mock analyzer

**Solution:**
1. Verify key is in environment:
   ```bash
   console.log(import.meta.env.VITE_OPENAI_API_KEY?.substring(0, 10))
   ```
2. Should output: `sk-proj-xx`
3. If not, restart dev server
4. Clear browser cache

---

## 📊 Testing the Integration

### Test 1: Simple Scam Message
```
Input: "مبروك! فزت بجائزة بقيمة 50,000 ريال"
Expected: High risk (80-95%)
```

### Test 2: Legitimate Message
```
Input: "مرحباً، كيف حالك؟"
Expected: Low risk (0-20%)
```

### Test 3: Phishing Email
```
Input: "تحقق من حسابك الآن. اضغط هنا لتحديث بياناتك"
Expected: High risk (85-100%)
```

---

## 🚀 Next Steps

1. ✅ Complete setup above
2. ✅ Test with sample messages
3. ✅ Monitor costs for first week
4. 🔜 Deploy to production with backend proxy
5. 🔜 Implement caching for cost savings
6. 🔜 Add user feedback loop for AI improvement

---

## 📞 Need Help?

### OpenAI Support
- **Docs:** [platform.openai.com/docs](https://platform.openai.com/docs)
- **Status:** [status.openai.com](https://status.openai.com)
- **Help:** [help.openai.com](https://help.openai.com)

### Khallak Nabeeh Support
- **Email:** support@khallaknabee.com
- **GitHub:** [Report Issue](https://github.com/yourusername/khallak-nabeeh/issues)

---

## 🔐 Security Tips

✅ **DO:**
- Keep API key secret
- Use environment variables
- Rotate keys regularly
- Monitor usage

❌ **DON'T:**
- Commit API key to GitHub
- Share key in messages
- Use key in frontend (production)
- Ignore usage alerts

---

**Setup Complete! 🎉**

Your Khallak Nabeeh app is now powered by real AI analysis.

Start analyzing scams at: **http://localhost:3000**
