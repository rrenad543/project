# خلك نبيه — Design Philosophy

## Three Stylistic Approaches

### 1. Digital Fortress (Probability: 0.07)
Dark cyberpunk with neon teal glows, grid overlays, and terminal aesthetics.
Feels like a hacker tool, not a consumer product.

### 2. Civic Trust (Probability: 0.04)
Government-inspired blues and whites, very formal and institutional.
Clean but cold — lacks warmth for everyday users.

### 3. Vigilant Clarity — CHOSEN (Probability: 0.09)
A warm-dark navy foundation with amber/gold accents — the visual language of
security badges, warning signals, and trusted authority. Feels protective and
approachable rather than intimidating.

---

## Chosen Approach: Vigilant Clarity

### Design Movement
Precision Security UI — inspired by professional threat-intelligence dashboards,
airport security signage, and Arabic calligraphic boldness. Not a "hacker tool"
— a trusted civic companion.

### Core Principles
1. **Trustworthy Authority** — Deep navy backgrounds signal credibility and calm.
2. **Amber Alert System** — Gold/amber is the signature warning color, used for risk indicators.
3. **Arabic-First Typography** — Bold Noto Kufi Arabic for headings; Cairo for body. RTL-native.
4. **Asymmetric Vigilance** — Layouts lean left (RTL), with content anchored to the right edge.

### Color Philosophy
- **Deep Navy** `oklch(0.18 0.04 255)` — primary background; authority, depth, trust
- **Amber Gold** `oklch(0.78 0.16 75)` — signature brand color; alert, energy, warmth
- **Slate Blue** `oklch(0.35 0.06 255)` — card surfaces; layered depth
- **Soft White** `oklch(0.95 0.005 80)` — body text; readable against dark
- **Danger Red** `oklch(0.62 0.22 25)` — high-risk alerts
- **Safe Green** `oklch(0.65 0.18 145)` — low-risk confirmation

### Layout Paradigm
Asymmetric hero with a large Arabic headline anchored right, analysis panel
floating left. Cards use staggered grid with subtle depth layers. No centered
hero text walls.

### Signature Elements
1. **Shield Motif** — Subtle shield SVG watermark in hero background
2. **Amber Gradient Borders** — Cards have a thin amber left-border (RTL: right-border)
3. **Scan Line Animation** — A slow horizontal scan line sweeps the analysis area during processing

### Interaction Philosophy
Every action feels deliberate and precise. Buttons have a firm press (scale 0.97).
Analysis results "reveal" with a staggered cascade. Risk meters fill with eased animation.

### Animation
- Entrance: `opacity 0→1` + `translateY 12px→0` over 300ms ease-out, staggered 60ms per item
- Analysis loading: rotating shield icon + scan line sweep
- Risk meter: animated fill from 0% to result value over 800ms cubic-bezier(0.23,1,0.32,1)
- Button press: scale(0.97) 160ms ease-out

### Typography System
- **Display**: Noto Kufi Arabic — Bold 700/800 for hero titles
- **Body**: Cairo — Regular 400, Medium 500 for UI text
- **Mono**: Courier New — for URL/link display only
- Scale: 48px hero → 32px section → 20px card title → 16px body → 14px caption

### Brand Essence
**خلك نبيه** — حارس رقمي للمواطن العربي العادي ضد الاحتيال الإلكتروني.
Personality: موثوق · يقظ · واضح

### Brand Voice
Headlines sound like a trusted friend warning you, not a corporate disclaimer.
- "لا تقع في الفخ — اكشف الاحتيال قبل فوات الأوان"
- "رسالة مشبوهة؟ دعنا نحللها لك في ثوانٍ"

### Wordmark & Logo
Shield icon with a stylized Arabic "ن" (Noon) inside — representing نبيه (alert/smart).
Gold on navy. Never just text in a default font.

### Signature Brand Color
**Amber Gold** `oklch(0.78 0.16 75)` — unmistakably خلك نبيه.

## Style Decisions
- All UI text is Arabic, RTL direction enforced at html level
- Risk levels use a three-tier color system: green (safe) / amber (caution) / red (danger)
- The analysis card uses a dark slate surface with amber right-border (RTL)
- Scan animation only plays during active analysis, not on idle
