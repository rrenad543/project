/**
 * Navbar — خلك نبيه
 * Vigilant Clarity theme: deep navy bg, amber logo, RTL layout
 */
import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Shield, Menu, X } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navLinks = [
    { label: "الرئيسية", href: "#hero" },
    { label: "كيف يعمل", href: "#how-it-works" },
    { label: "إحصائيات", href: "#stats" },
    { label: "نصائح الأمان", href: "#tips" },
  ];

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 right-0 left-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[oklch(0.18_0.04_255/0.95)] backdrop-blur-xl shadow-lg shadow-black/30 border-b border-white/10"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo — right side in RTL */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="relative">
              <img
                src="/manus-storage/logo-shield_59a57340.png"
                alt="خلك نبيه"
                className="w-9 h-9 object-contain group-hover:scale-110 transition-transform duration-200"
              />
            </div>
            <div className="flex flex-col leading-tight">
              <span
                className="text-lg font-black text-[oklch(0.78_0.16_75)]"
                style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
              >
                خلك نبيه
              </span>
              <span className="text-[10px] text-white/50 font-light tracking-wide">
                كاشف الاحتيال الإلكتروني
              </span>
            </div>
          </Link>

          {/* Desktop nav — left side in RTL */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="px-4 py-2 text-sm text-white/70 hover:text-[oklch(0.78_0.16_75)] hover:bg-white/5 rounded-lg transition-all duration-200 font-medium"
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => handleNavClick("#analyzer")}
              className="mr-2 px-5 py-2 bg-[oklch(0.78_0.16_75)] text-[oklch(0.18_0.04_255)] rounded-lg text-sm font-bold hover:bg-[oklch(0.85_0.14_75)] active:scale-[0.97] transition-all duration-160"
              style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
            >
              ابدأ التحليل
            </button>
          </nav>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden p-2 text-white/70 hover:text-white transition-colors"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="القائمة"
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-[oklch(0.20_0.04_255/0.98)] backdrop-blur-xl border-t border-white/10 px-4 py-4 space-y-1">
          {navLinks.map((link) => (
            <button
              key={link.href}
              onClick={() => handleNavClick(link.href)}
              className="w-full text-right px-4 py-3 text-white/80 hover:text-[oklch(0.78_0.16_75)] hover:bg-white/5 rounded-lg transition-all duration-200 font-medium"
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => handleNavClick("#analyzer")}
            className="w-full mt-2 px-5 py-3 bg-[oklch(0.78_0.16_75)] text-[oklch(0.18_0.04_255)] rounded-lg font-bold hover:bg-[oklch(0.85_0.14_75)] transition-all duration-160"
            style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
          >
            ابدأ التحليل
          </button>
        </div>
      )}
    </header>
  );
}
