/**
 * HowItWorksSection — خلك نبيه
 * RTL-asymmetric layout, amber right-border cards, security instrumentation cues
 */
import { ClipboardPaste, Cpu, ShieldCheck, ArrowLeft } from "lucide-react";

const STEPS = [
  {
    number: "٠١",
    icon: <ClipboardPaste size={24} />,
    title: "الصق المحتوى",
    description: "انسخ الرسالة أو البريد الإلكتروني أو الرابط المشبوه والصقه في حقل التحليل.",
    tag: "إدخال البيانات",
  },
  {
    number: "٠٢",
    icon: <Cpu size={24} />,
    title: "حلّل الآن",
    description: "يقوم محرك الذكاء الاصطناعي بفحص المحتوى وتحليل أنماط الاحتيال المعروفة في ثوانٍ.",
    tag: "المعالجة الذكية",
  },
  {
    number: "٠٣",
    icon: <ShieldCheck size={24} />,
    title: "اعرف الحقيقة",
    description: "احصل على تقرير فوري يوضح مستوى الخطورة ونوع التهديد والتوصيات اللازمة.",
    tag: "تقرير التهديد",
  },
];

export default function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-20 px-4 bg-[oklch(0.18_0.04_255)] relative overflow-hidden">
      {/* Subtle grid background */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: "linear-gradient(oklch(0.78_0.16_75) 1px, transparent 1px), linear-gradient(90deg, oklch(0.78_0.16_75) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div className="max-w-5xl mx-auto relative">
        {/* RTL-asymmetric header — right-led */}
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-[oklch(0.78_0.16_75)]" />
            <p className="text-[oklch(0.78_0.16_75)] text-xs font-bold tracking-[0.2em] uppercase">
              آلية العمل
            </p>
          </div>
          <h2
            className="text-3xl md:text-4xl font-black text-white mb-3"
            style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
          >
            ثلاث خطوات بسيطة
          </h2>
          <p className="text-white/50 text-sm max-w-sm">
            كشف الاحتيال لم يكن أسهل من هذا — بدون تسجيل، بدون رسوم
          </p>
        </div>

        {/* Steps — staggered RTL layout */}
        <div className="space-y-4">
          {STEPS.map((step, i) => (
            <div
              key={i}
              className="group relative flex items-stretch gap-0 rounded-2xl overflow-hidden border border-white/8 hover:border-[oklch(0.78_0.16_75/0.3)] transition-all duration-300 hover:shadow-lg hover:shadow-[oklch(0.78_0.16_75/0.08)]"
              style={{ marginRight: `${i * 24}px` }}
            >
              {/* Amber right-border (RTL signature motif) */}
              <div className="w-1 shrink-0 bg-gradient-to-b from-[oklch(0.78_0.16_75)] to-[oklch(0.78_0.16_75/0.3)]" />

              <div className="flex-1 bg-[oklch(0.22_0.045_255)] p-5 flex items-center gap-5">
                {/* Step number */}
                <div
                  className="shrink-0 text-3xl font-black text-[oklch(0.78_0.16_75/0.2)] group-hover:text-[oklch(0.78_0.16_75/0.4)] transition-colors duration-300 leading-none w-12 text-center"
                  style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
                >
                  {step.number}
                </div>

                {/* Icon */}
                <div className="shrink-0 w-11 h-11 rounded-xl bg-[oklch(0.78_0.16_75/0.1)] border border-[oklch(0.78_0.16_75/0.2)] flex items-center justify-center text-[oklch(0.78_0.16_75)] group-hover:bg-[oklch(0.78_0.16_75/0.18)] transition-colors duration-300">
                  {step.icon}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3
                      className="text-base font-bold text-white"
                      style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
                    >
                      {step.title}
                    </h3>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[oklch(0.78_0.16_75/0.1)] text-[oklch(0.78_0.16_75/0.7)] border border-[oklch(0.78_0.16_75/0.15)]">
                      {step.tag}
                    </span>
                  </div>
                  <p className="text-sm text-white/50 leading-relaxed">{step.description}</p>
                </div>

                {/* Arrow connector */}
                {i < STEPS.length - 1 && (
                  <div className="shrink-0 text-white/20 group-hover:text-[oklch(0.78_0.16_75/0.4)] transition-colors duration-300">
                    <ArrowLeft size={16} />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
