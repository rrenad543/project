/**
 * Home — خلك نبيه
 * Main page assembling all sections
 * Vigilant Clarity design: dark navy + amber gold, RTL, Arabic-first
 */
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import AnalyzerSection from "@/components/AnalyzerSection";
import StatsSection from "@/components/StatsSection";
import TipsSection from "@/components/TipsSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-[oklch(0.18_0.04_255)]" dir="rtl">
      <Navbar />
      <HeroSection />
      <HowItWorksSection />
      <AnalyzerSection />
      <StatsSection />
      <TipsSection />
      <Footer />
    </div>
  );
}
