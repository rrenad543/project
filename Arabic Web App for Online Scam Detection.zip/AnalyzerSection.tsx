/**
 * AnalyzerSection — خلك نبيه
 * Threat-intelligence core: security instrumentation, scan grid, amber right-border
 * Vigilant Clarity design system
 */
import { useState } from "react";
import { Shield, MessageSquare, Mail, Link2, Loader2, Terminal, Activity } from "lucide-react";
import { analyzeContent, ContentType, AnalysisResult } from "@/lib/scamAnalyzer";
import AnalysisResultCard from "./AnalysisResultCard";

const CONTENT_TYPES: { id: ContentType; label: string; icon: React.ReactNode; placeholder: string }[] = [
  {
    id: "message",
    label: "رسالة نصية",
    icon: <MessageSquare size={16} />,
    placeholder: "الصق نص الرسالة المشبوهة هنا...\n\nمثال: مبروك! لقد فزت بجائزة بقيمة 50,000 ريال. اضغط هنا للمطالبة بجائزتك...",
  },
  {
    id: "email",
    label: "بريد إلكتروني",
    icon: <Mail size={16} />,
    placeholder: "الصق محتوى البريد الإلكتروني المشبوه هنا...\n\nيمكنك نسخ موضوع الرسالة ومحتواها كاملاً...",
  },
  {
    id: "link",
    label: "رابط",
    icon: <Link2 size={16} />,
    placeholder: "الصق الرابط المشبوه هنا...\n\nمثال: http://bit.ly/free-prize-claim",
  },
];

export default function AnalyzerSection() {
  const [contentType, setContentType] = useState<ContentType>("message");
  const [content, setContent] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [scanProgress, setScanProgress] = useState(0);

  const selectedType = CONTENT_TYPES.find((t) => t.id === contentType)!;

  const handleAnalyze = async () => {
    if (!content.trim()) return;
    setIsAnalyzing(true);
    setResult(null);
    setScanProgress(0);

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 90) { clearInterval(interval); return 90; }
        return prev + Math.random() * 12;
      });
    }, 200);

    try {
      const analysisResult = await analyzeContent(content, contentType);
      clearInterval(interval);
      setScanProgress(100);
      setTimeout(() => {
        setResult(analysisResult);
        setIsAnalyzing(false);
      }, 400);
    } catch {
      clearInterval(interval);
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setContent("");
    setScanProgress(0);
  };

  return (
    <section id="analyzer" className="py-20 px-4 relative bg-[oklch(0.16_0.038_255)]">
      {/* Security grid background */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage: "linear-gradient(oklch(0.78_0.16_75) 1px, transparent 1px), linear-gradient(90deg, oklch(0.78_0.16_75) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />
      {/* Amber glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-[oklch(0.78_0.16_75/0.04)] rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-3xl mx-auto relative">
        {/* RTL-asymmetric header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-[oklch(0.78_0.16_75)]" />
            <p className="text-[oklch(0.78_0.16_75)] text-xs font-bold tracking-[0.2em] uppercase flex items-center gap-1.5">
              <Activity size={11} />
              <span>محرك التحليل الذكي</span>
            </p>
          </div>
          <h2
            className="text-3xl md:text-4xl font-black text-white mb-3"
            style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
          >
            حلّل المحتوى المشبوه
          </h2>
          <p className="text-white/50 text-sm max-w-sm">
            الصق الرسالة أو البريد الإلكتروني أو الرابط — سنكشف لك الحقيقة في ثوانٍ
          </p>
        </div>

        {/* Main threat-intelligence panel */}
        <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-black/50">
          {/* Amber right-border (RTL signature motif) */}
          <div className="absolute top-0 right-0 bottom-0 w-1 bg-gradient-to-b from-[oklch(0.78_0.16_75)] via-[oklch(0.78_0.16_75/0.5)] to-transparent z-10" />

          {/* Panel header bar */}
          <div className="bg-[oklch(0.20_0.042_255)] border border-white/10 border-b-0 rounded-t-2xl px-5 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal size={13} className="text-[oklch(0.78_0.16_75)]" />
              <span className="text-xs font-mono text-[oklch(0.78_0.16_75/0.8)]">THREAT_ANALYZER_v2.1</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-[oklch(0.65_0.18_145)] animate-pulse" />
              <span className="text-[10px] text-white/40">نشط</span>
            </div>
          </div>

          {/* Main card body */}
          <div className="bg-[oklch(0.22_0.045_255)] border border-white/10 border-t-0 rounded-b-2xl p-6 md:p-8">
            {/* Content type selector */}
            <div className="mb-6">
              <label className="block text-xs font-semibold text-white/40 mb-3 tracking-wider uppercase">
                نوع المحتوى
              </label>
              <div className="grid grid-cols-3 gap-2">
                {CONTENT_TYPES.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => { setContentType(type.id); setResult(null); }}
                    className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border text-sm font-medium transition-all duration-200 active:scale-[0.97] ${
                      contentType === type.id
                        ? "bg-[oklch(0.78_0.16_75/0.15)] border-[oklch(0.78_0.16_75/0.5)] text-[oklch(0.88_0.12_80)]"
                        : "bg-white/4 border-white/8 text-white/50 hover:bg-white/8 hover:text-white/70"
                    }`}
                  >
                    <span className={contentType === type.id ? "text-[oklch(0.78_0.16_75)]" : ""}>{type.icon}</span>
                    <span>{type.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Textarea */}
            <div className="mb-6">
              <label className="block text-xs font-semibold text-white/40 mb-3 tracking-wider uppercase">
                المحتوى المراد تحليله
              </label>
              <div className="relative">
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder={selectedType.placeholder}
                  rows={6}
                  disabled={isAnalyzing}
                  className="w-full bg-[oklch(0.15_0.033_255)] border border-white/8 rounded-xl px-4 py-3 text-white/90 placeholder-white/20 text-sm leading-relaxed resize-none focus:outline-none focus:border-[oklch(0.78_0.16_75/0.4)] focus:ring-1 focus:ring-[oklch(0.78_0.16_75/0.15)] transition-all duration-200 disabled:opacity-50"
                  style={{ fontFamily: "'Cairo', sans-serif", direction: "rtl" }}
                />
                {/* Scan line animation during analysis */}
                {isAnalyzing && (
                  <div className="absolute inset-0 rounded-xl overflow-hidden pointer-events-none">
                    <div
                      className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[oklch(0.78_0.16_75/0.6)] to-transparent"
                      style={{
                        animation: "scanLine 1.5s linear infinite",
                      }}
                    />
                  </div>
                )}
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-[10px] text-white/25 font-mono">{content.length} chars</span>
                {content && !isAnalyzing && (
                  <button
                    onClick={() => { setContent(""); setResult(null); }}
                    className="text-[10px] text-white/30 hover:text-white/60 transition-colors font-mono"
                  >
                    [مسح]
                  </button>
                )}
              </div>
            </div>

            {/* Scan progress */}
            {isAnalyzing && (
              <div className="mb-6 bg-[oklch(0.15_0.033_255)] border border-white/8 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-[oklch(0.78_0.16_75)] font-mono animate-pulse">
                    &gt; جارٍ فحص الأنماط...
                  </span>
                  <span className="text-xs text-white/30 font-mono">{Math.round(scanProgress)}%</span>
                </div>
                <div className="h-1 bg-white/8 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-l from-[oklch(0.78_0.16_75)] to-[oklch(0.88_0.12_80)] rounded-full transition-all duration-300"
                    style={{ width: `${scanProgress}%` }}
                  />
                </div>
                <div className="mt-2 text-[10px] text-white/25 font-mono space-y-0.5">
                  <p>&gt; تحليل الأنماط اللغوية...</p>
                  {scanProgress > 30 && <p>&gt; فحص مؤشرات التصيد...</p>}
                  {scanProgress > 60 && <p>&gt; مقارنة قاعدة بيانات التهديدات...</p>}
                  {scanProgress > 85 && <p>&gt; إعداد التقرير النهائي...</p>}
                </div>
              </div>
            )}

            {/* Analyze button */}
            <button
              onClick={handleAnalyze}
              disabled={!content.trim() || isAnalyzing}
              className="w-full py-4 bg-[oklch(0.78_0.16_75)] text-[oklch(0.14_0.04_255)] rounded-xl font-black text-lg hover:bg-[oklch(0.84_0.14_75)] active:scale-[0.98] disabled:opacity-35 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center gap-3 shadow-lg shadow-[oklch(0.78_0.16_75/0.2)]"
              style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
            >
              {isAnalyzing ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  <span>جارٍ التحليل...</span>
                </>
              ) : (
                <>
                  <Shield size={20} />
                  <span>حلّل الآن</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Result card */}
        {result && (
          <div className="mt-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <AnalysisResultCard result={result} onReset={handleReset} />
          </div>
        )}
      </div>

      <style>{`
        @keyframes scanLine {
          0% { top: 0%; }
          100% { top: 100%; }
        }
      `}</style>
    </section>
  );
}
