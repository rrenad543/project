# OpenAI Integration Guide
## Khallak Nabeeh — Real AI-Powered Scam Detection

This guide explains how to integrate OpenAI's GPT-4 API into Khallak Nabeeh for real-time scam analysis.

---

## 📋 Table of Contents

1. [Getting Your API Key](#getting-your-api-key)
2. [Setting Up Environment Variables](#setting-up-environment-variables)
3. [Integration Steps](#integration-steps)
4. [Testing the Integration](#testing-the-integration)
5. [Troubleshooting](#troubleshooting)
6. [Cost Estimation](#cost-estimation)

---

## 🔑 Getting Your API Key

### Step 1: Create OpenAI Account
1. Visit [platform.openai.com](https://platform.openai.com)
2. Click "Sign up" or "Sign in"
3. Complete the registration process
4. Verify your email address

### Step 2: Generate API Key
1. Go to [API Keys page](https://platform.openai.com/api-keys)
2. Click "Create new secret key"
3. Copy the key (you'll only see it once!)
4. Store it safely

### Step 3: Set Up Billing
1. Go to [Billing settings](https://platform.openai.com/account/billing/overview)
2. Add a payment method
3. Set usage limits to prevent unexpected charges
4. Monitor your usage regularly

**Your API Key format:**
```
sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

---

## 🔐 Setting Up Environment Variables

### Option 1: Using Manus Platform (Recommended)

1. Go to **Management UI → Settings → Secrets**
2. Click **"Add Secret"**
3. Enter:
   - **Key:** `VITE_OPENAI_API_KEY`
   - **Value:** `sk-proj-your-actual-key-here`
4. Click **"Save"**
5. Restart the development server

### Option 2: Local Development (.env.local)

1. Create `.env.local` file in project root:
```bash
touch .env.local
```

2. Add your API key:
```env
VITE_OPENAI_API_KEY=sk-proj-your-actual-key-here
VITE_OPENAI_MODEL=gpt-4-turbo
```

3. Restart development server:
```bash
pnpm run dev
```

### Option 3: Using Shell Environment
```bash
export VITE_OPENAI_API_KEY=sk-proj-your-actual-key-here
pnpm run dev
```

---

## 🔧 Integration Steps

### Step 1: Update the Analyzer Engine

Replace the mock analyzer with real OpenAI integration:

**File:** `client/src/lib/scamAnalyzer.ts`

```typescript
import { analyzeContent as analyzeWithOpenAI } from "./openaiAnalyzer";

export async function analyzeContent(
  content: string,
  contentType: ContentType
): Promise<AnalysisResult> {
  // Use real OpenAI API if key is available
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (apiKey && apiKey.startsWith("sk-")) {
    return await analyzeWithOpenAI(content, contentType);
  }
  
  // Fallback to mock analyzer for demo
  return await analyzeMockContent(content, contentType);
}
```

### Step 2: Create OpenAI Analyzer Module

**File:** `client/src/lib/openaiAnalyzer.ts`

```typescript
import { ContentType, AnalysisResult, RiskLevel } from "./scamAnalyzer";

const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
const MODEL = import.meta.env.VITE_OPENAI_MODEL || "gpt-4-turbo";

const SYSTEM_PROMPT = `You are an expert cybersecurity analyst specializing in Arabic scam detection.
Analyze the provided content and determine if it's a scam.

Respond in JSON format:
{
  "riskLevel": "safe" | "caution" | "danger",
  "riskScore": 0-100,
  "threatType": "phishing" | "prize_scam" | "investment_fraud" | "identity_theft" | "malicious_link" | "social_engineering" | "suspicious_offer" | "general_spam" | "safe",
  "details": ["red flag 1", "red flag 2", ...],
  "recommendation": "actionable recommendation"
}`;

export async function analyzeContent(
  content: string,
  contentType: ContentType
): Promise<AnalysisResult> {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey) {
    throw new Error("OpenAI API key not configured");
  }

  const userPrompt = `Analyze this ${contentType} for scam indicators:\n\n${content}`;

  try {
    const response = await fetch(OPENAI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.3,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`OpenAI API error: ${error.error?.message}`);
    }

    const data = await response.json();
    const analysisText = data.choices[0].message.content;
    const analysis = JSON.parse(analysisText);

    return {
      riskLevel: analysis.riskLevel as RiskLevel,
      riskScore: analysis.riskScore,
      threatType: analysis.threatType,
      details: analysis.details,
      recommendation: analysis.recommendation,
      showKullunAmn: analysis.riskLevel === "danger",
    };
  } catch (error) {
    console.error("Analysis error:", error);
    throw error;
  }
}
```

### Step 3: Update AnalyzerSection Component

**File:** `client/src/components/AnalyzerSection.tsx`

Add error handling for API failures:

```typescript
const handleAnalyze = async () => {
  if (!content.trim()) return;
  setIsAnalyzing(true);
  setResult(null);
  setScanProgress(0);

  try {
    const analysisResult = await analyzeContent(content, contentType);
    setResult(analysisResult);
  } catch (error) {
    console.error("Analysis failed:", error);
    // Show error toast
    toast.error("التحليل فشل. يرجى المحاولة لاحقاً.");
  } finally {
    setIsAnalyzing(false);
  }
};
```

---

## ✅ Testing the Integration

### Test 1: Verify API Key
```typescript
// In browser console
console.log(import.meta.env.VITE_OPENAI_API_KEY?.substring(0, 10));
// Should output: sk-proj-xx
```

### Test 2: Simple Analysis
1. Open the app
2. Paste a test message: "مبروك! فزت بجائزة بقيمة 50,000 ريال. اضغط هنا"
3. Click "حلّل الآن"
4. Should return high risk score

### Test 3: Monitor API Usage
1. Visit [OpenAI Usage page](https://platform.openai.com/account/usage/overview)
2. Check that requests are being logged
3. Verify costs are within budget

### Test 4: Error Handling
1. Temporarily disable API key in settings
2. Try to analyze content
3. Should show error message gracefully

---

## 🐛 Troubleshooting

### Issue: "API key not configured"
**Solution:**
```bash
# Check if key is set
echo $VITE_OPENAI_API_KEY

# Restart dev server
pnpm run dev
```

### Issue: "Invalid API Key"
**Solution:**
1. Verify key format: `sk-proj-...`
2. Check key hasn't expired (regenerate if needed)
3. Ensure no extra spaces or characters

### Issue: "Rate limit exceeded"
**Solution:**
1. Wait a few minutes before retrying
2. Upgrade OpenAI plan for higher limits
3. Implement request queuing

### Issue: "Timeout after 30 seconds"
**Solution:**
1. Check internet connection
2. Increase timeout in `.env.local`:
```env
VITE_API_TIMEOUT=60000
```

### Issue: "CORS error"
**Solution:**
This is expected for client-side API calls. For production, use a backend proxy:
```typescript
// Instead of direct API call
const response = await fetch("/api/analyze", {
  method: "POST",
  body: JSON.stringify({ content, contentType }),
});
```

---

## 💰 Cost Estimation

### Pricing (as of July 2026)
| Model | Input | Output |
|---|---|---|
| GPT-4 Turbo | $0.01 / 1K tokens | $0.03 / 1K tokens |
| GPT-4o | $0.005 / 1K tokens | $0.015 / 1K tokens |
| GPT-3.5 Turbo | $0.0005 / 1K tokens | $0.0015 / 1K tokens |

### Cost per Analysis
- Average tokens per analysis: 200 input + 100 output
- Using GPT-4 Turbo: ~$0.005 per analysis
- Using GPT-4o: ~$0.0015 per analysis

### Monthly Budget Examples
| Users | Analyses/Month | GPT-4 Turbo | GPT-4o |
|---|---|---|---|
| 1,000 | 50,000 | $250 | $75 |
| 10,000 | 500,000 | $2,500 | $750 |
| 100,000 | 5,000,000 | $25,000 | $7,500 |

### Cost Optimization Tips
1. **Use GPT-4o** instead of GPT-4 Turbo (3x cheaper)
2. **Implement caching** for repeated queries
3. **Batch requests** during off-peak hours
4. **Set usage limits** in OpenAI dashboard
5. **Monitor costs** weekly

---

## 🚀 Production Deployment

### For Production, Use Backend Proxy

Instead of exposing API key in frontend:

**Backend Endpoint:** `POST /api/v1/analyze`

```typescript
// Backend (Node.js + Express)
app.post("/api/v1/analyze", async (req, res) => {
  const { content, contentType } = req.body;
  
  try {
    const result = await analyzeWithOpenAI(content, contentType);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

**Frontend Call:**
```typescript
const response = await fetch("/api/v1/analyze", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ content, contentType }),
});
```

### Security Best Practices
- ✅ Never expose API key in frontend code
- ✅ Use backend proxy for API calls
- ✅ Implement rate limiting
- ✅ Add authentication for API access
- ✅ Monitor for suspicious activity
- ✅ Rotate API keys regularly

---

## 📞 Support

### OpenAI Support
- [Documentation](https://platform.openai.com/docs)
- [Help Center](https://help.openai.com)
- [Status Page](https://status.openai.com)

### Khallak Nabeeh Support
- Email: support@khallaknabee.com
- GitHub Issues: [Report Issue](https://github.com/yourusername/khallak-nabeeh/issues)

---

## ✨ Next Steps

1. ✅ Get OpenAI API Key
2. ✅ Set up environment variables
3. ✅ Integrate OpenAI analyzer
4. ✅ Test with real data
5. ✅ Monitor costs and performance
6. 🔜 Deploy to production with backend proxy
7. 🔜 Implement caching and optimization

---

**Last Updated:** July 2026  
**Version:** 1.0  
**Status:** Ready for Integration
