/**
 * OpenAI Analyzer — خلك نبيه
 * Real AI-powered scam detection using GPT-4 Turbo
 * 
 * This module replaces the mock analyzer with actual OpenAI API calls
 * for production-grade scam analysis.
 */

import { ContentType, AnalysisResult, RiskLevel } from "./scamAnalyzer";

const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
const MODEL = "gpt-4-turbo";
const MAX_RETRIES = 3;
const TIMEOUT_MS = 30000;

/**
 * System prompt for GPT-4 to analyze scams in Arabic
 */
const SYSTEM_PROMPT = `أنت خبير متخصص في تحليل الاحتيال الإلكتروني والتصيد الاحتيالي باللغة العربية.
مهمتك تحليل المحتوى المقدم وتحديد ما إذا كان محاولة احتيال أم لا.

قيّم المحتوى بناءً على:
1. الأنماط اللغوية المشبوهة
2. طلبات البيانات الشخصية أو المالية
3. الوعود غير الواقعية (جوائز، أرباح)
4. الروابط المختصرة أو المريبة
5. محاولات الإلحاح والاستعجالية
6. انتحال الهوية (بنوك، جهات حكومية)

استجب بصيغة JSON فقط (بدون نص إضافي):
{
  "riskLevel": "safe" | "caution" | "danger",
  "riskScore": 0-100,
  "threatType": "phishing" | "prize_scam" | "investment_fraud" | "identity_theft" | "malicious_link" | "social_engineering" | "suspicious_offer" | "general_spam" | "safe",
  "details": ["علامة تحذير 1", "علامة تحذير 2", ...],
  "recommendation": "توصية قابلة للتنفيذ"
}`;

/**
 * Threat type labels in Arabic
 */
const THREAT_LABELS: Record<string, string> = {
  phishing: "تصيد احتيالي",
  prize_scam: "احتيال الجوائز الوهمية",
  investment_fraud: "احتيال استثماري",
  identity_theft: "سرقة الهوية",
  malicious_link: "رابط ضار",
  social_engineering: "هندسة اجتماعية",
  suspicious_offer: "عرض مشبوه",
  general_spam: "بريد مزعج",
  safe: "لا تهديد واضح",
};

/**
 * Fetch with timeout support
 */
async function fetchWithTimeout(
  url: string,
  options: RequestInit,
  timeoutMs: number = TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

/**
 * Call OpenAI API with retry logic
 */
async function callOpenAIAPI(
  userPrompt: string,
  contentType: ContentType,
  retryCount: number = 0
): Promise<string> {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;

  if (!apiKey || !apiKey.startsWith("sk-")) {
    throw new Error(
      "OpenAI API key not configured. Please set VITE_OPENAI_API_KEY in environment variables."
    );
  }

  try {
    const response = await fetchWithTimeout(
      OPENAI_API_URL,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: MODEL,
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            { role: "user", content: userPrompt },
          ],
          temperature: 0.3, // Lower temperature for consistent results
          max_tokens: 500,
          top_p: 0.9,
        }),
      },
      TIMEOUT_MS
    );

    if (!response.ok) {
      const error = await response.json();
      const errorMessage = error.error?.message || "Unknown error";

      // Handle specific error cases
      if (response.status === 401) {
        throw new Error("Invalid OpenAI API key");
      } else if (response.status === 429) {
        // Rate limited - retry with exponential backoff
        if (retryCount < MAX_RETRIES) {
          const delay = Math.pow(2, retryCount) * 1000;
          await new Promise((resolve) => setTimeout(resolve, delay));
          return callOpenAIAPI(userPrompt, contentType, retryCount + 1);
        }
        throw new Error("Rate limit exceeded. Please try again later.");
      } else if (response.status === 500) {
        throw new Error("OpenAI service error. Please try again later.");
      }

      throw new Error(`OpenAI API error: ${errorMessage}`);
    }

    const data = await response.json();
    const analysisText = data.choices?.[0]?.message?.content;

    if (!analysisText) {
      throw new Error("Invalid response from OpenAI API");
    }

    return analysisText;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("Failed to call OpenAI API");
  }
}

/**
 * Parse and validate OpenAI response
 */
function parseAnalysisResponse(responseText: string): Partial<AnalysisResult> {
  try {
    // Extract JSON from response (in case there's extra text)
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON found in response");
    }

    const analysis = JSON.parse(jsonMatch[0]);

    // Validate required fields
    if (
      !["safe", "caution", "danger"].includes(analysis.riskLevel) ||
      typeof analysis.riskScore !== "number" ||
      analysis.riskScore < 0 ||
      analysis.riskScore > 100 ||
      !Array.isArray(analysis.details) ||
      typeof analysis.recommendation !== "string"
    ) {
      throw new Error("Invalid analysis response format");
    }

    return {
      riskLevel: analysis.riskLevel as RiskLevel,
      riskScore: Math.round(analysis.riskScore),
      threatType: analysis.threatType || "safe",
      details: analysis.details.slice(0, 5), // Limit to 5 details
      recommendation: analysis.recommendation,
      showKullunAmn: analysis.riskLevel === "danger",
    };
  } catch (error) {
    console.error("Failed to parse analysis response:", error);
    throw new Error("Failed to parse AI analysis response");
  }
}

/**
 * Main analysis function using OpenAI API
 */
export async function analyzeContent(
  content: string,
  contentType: ContentType
): Promise<AnalysisResult> {
  if (!content.trim()) {
    return {
      riskLevel: "safe",
      riskScore: 0,
      threatType: "safe",
      details: ["لم يتم إدخال أي محتوى للتحليل"],
      recommendation: "الرجاء إدخال المحتوى المراد تحليله",
      showKullunAmn: false,
    };
  }

  try {
    // Build user prompt based on content type
    const contentTypeLabel =
      contentType === "message"
        ? "رسالة نصية"
        : contentType === "email"
          ? "بريد إلكتروني"
          : "رابط";

    const userPrompt = `حلّل هذا/${contentTypeLabel} للتحقق من مؤشرات الاحتيال:\n\n${content}`;

    // Call OpenAI API
    const responseText = await callOpenAIAPI(userPrompt, contentType);

    // Parse response
    const analysis = parseAnalysisResponse(responseText);

    // Return complete analysis result
    return {
      riskLevel: analysis.riskLevel || "safe",
      riskScore: analysis.riskScore || 0,
      threatType: analysis.threatType || "safe",
      details: analysis.details || ["لم يتم اكتشاف معلومات كافية"],
      recommendation:
        analysis.recommendation || "يرجى توخي الحذر عند التعامل مع هذا المحتوى",
      showKullunAmn: analysis.showKullunAmn || false,
    };
  } catch (error) {
    console.error("Analysis error:", error);

    // Return error result instead of throwing
    return {
      riskLevel: "caution",
      riskScore: 50,
      threatType: "safe",
      details: [
        "حدث خطأ أثناء التحليل",
        "يرجى المحاولة لاحقاً",
        error instanceof Error ? error.message : "خطأ غير معروف",
      ],
      recommendation:
        "لم نتمكن من تحليل المحتوى. يرجى المحاولة لاحقاً أو التحقق من اتصالك بالإنترنت.",
      showKullunAmn: false,
    };
  }
}

/**
 * Test API connection
 */
export async function testAPIConnection(): Promise<boolean> {
  try {
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (!apiKey) {
      console.warn("OpenAI API key not configured");
      return false;
    }

    const response = await fetchWithTimeout(
      OPENAI_API_URL,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: MODEL,
          messages: [{ role: "user", content: "test" }],
          max_tokens: 10,
        }),
      },
      5000 // 5 second timeout for test
    );

    return response.ok || response.status === 400; // 400 is OK for test (invalid request)
  } catch (error) {
    console.error("API connection test failed:", error);
    return false;
  }
}

/**
 * Get API usage info
 */
export function getAPIInfo(): {
  configured: boolean;
  model: string;
  apiUrl: string;
} {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  return {
    configured: !!apiKey && apiKey.startsWith("sk-"),
    model: MODEL,
    apiUrl: OPENAI_API_URL,
  };
}
