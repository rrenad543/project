/**
 * خلك نبيه — Scam Analysis Engine
 * Real AI-powered analysis using OpenAI GPT-4 Turbo
 * Falls back to mock analyzer if API key not available
 */

export type ContentType = "message" | "email" | "link";

export type RiskLevel = "safe" | "caution" | "danger";

export interface AnalysisResult {
  riskLevel: RiskLevel;
  riskScore: number; // 0-100
  threatType: string;
  details: string[];
  recommendation: string;
  showKullunAmn: boolean;
}

// Suspicious patterns for Arabic scam detection
const DANGER_PATTERNS = [
  /فوز|جائزة|مبروك|ربحت|مليون|ألف ريال|ألف دولار/i,
  /اضغط هنا|انقر الآن|سارع|عاجل|فوري/i,
  /كلمة المرور|رقم البطاقة|بياناتك|معلوماتك الشخصية/i,
  /تحقق من حسابك|تأكيد الهوية|تحديث البيانات/i,
  /bit\.ly|tinyurl|t\.co\/|goo\.gl/i,
  /مجاني|مجانا|مجانًا|بدون مقابل/i,
  /استثمار|أرباح|عائد|ضمان ربح/i,
  /ورث|ميراث|مبلغ ضخم|تحويل أموال/i,
  /http:\/\//i, // non-HTTPS links
  /verify|confirm|update|login|signin/i,
];

const CAUTION_PATTERNS = [
  /عرض خاص|خصم|تخفيض|عرض محدود/i,
  /اتصل بنا|تواصل معنا|أرسل رقمك/i,
  /بنك|مصرف|حساب|رصيد/i,
  /whatsapp|واتساب|تيليغرام|telegram/i,
  /رابط|link|url/i,
];

const THREAT_TYPES: Record<string, string> = {
  phishing: "تصيد احتيالي (Phishing)",
  prize_scam: "احتيال الجوائز الوهمية",
  investment_fraud: "احتيال استثماري",
  identity_theft: "سرقة الهوية",
  malicious_link: "رابط ضار",
  social_engineering: "هندسة اجتماعية",
  suspicious_offer: "عرض مشبوه",
  general_spam: "بريد مزعج",
  safe: "لا تهديد واضح",
};

function detectThreatType(content: string, contentType: ContentType): string {
  const lower = content.toLowerCase();

  if (/فوز|جائزة|ربحت|مبروك/.test(content)) return "prize_scam";
  if (/استثمار|أرباح|عائد|ضمان ربح/.test(content)) return "investment_fraud";
  if (/كلمة المرور|رقم البطاقة|بياناتك/.test(content)) return "identity_theft";
  if (/ورث|ميراث|تحويل أموال/.test(content)) return "phishing";
  if (contentType === "link" && /http:\/\//.test(content)) return "malicious_link";
  if (contentType === "link") return "malicious_link";
  if (/عرض خاص|خصم|تخفيض/.test(content)) return "suspicious_offer";
  if (/بنك|مصرف|حساب|رصيد|verify|confirm/.test(lower)) return "phishing";
  if (/اضغط|انقر|سارع|عاجل/.test(content)) return "social_engineering";
  if (CAUTION_PATTERNS.some((p) => p.test(content))) return "general_spam";

  return "safe";
}

function generateDetails(
  content: string,
  contentType: ContentType,
  riskLevel: string,
  threatType: string
): string[] {
  const details: string[] = [];

  if (riskLevel === "safe") {
    details.push("لم يتم اكتشاف أنماط احتيالية واضحة");
    details.push("المحتوى يبدو طبيعياً");
    if (contentType === "link") details.push("الرابط يستخدم بروتوكول HTTPS الآمن");
    return details;
  }

  if (/فوز|جائزة|ربحت/.test(content)) details.push("يحتوي على وعود بجوائز غير واقعية");
  if (/عاجل|فوري|سارع/.test(content)) details.push("يستخدم أسلوب الإلحاح لاستفزاز ردود فعل متسرعة");
  if (/كلمة المرور|رقم البطاقة/.test(content)) details.push("يطلب معلومات مالية أو شخصية حساسة");
  if (/bit\.ly|tinyurl|t\.co/.test(content)) details.push("يحتوي على روابط مختصرة مشبوهة");
  if (/http:\/\//.test(content)) details.push("الرابط غير مشفر (HTTP بدلاً من HTTPS)");
  if (/استثمار|أرباح/.test(content)) details.push("يعد بعوائد استثمارية غير واقعية");
  if (/ورث|ميراث/.test(content)) details.push("يستخدم قصة ميراث أو ثروة وهمية");
  if (/بنك|مصرف|verify/.test(content.toLowerCase())) details.push("ينتحل صفة مؤسسة مالية أو بنك");
  if (contentType === "email" && riskLevel !== "safe") details.push("البريد الإلكتروني يحتوي على مؤشرات تصيد احتيالي");

  if (details.length === 0) {
    details.push("يحتوي على أنماط مشبوهة تستدعي الحذر");
    details.push("يُنصح بالتحقق من المصدر قبل التفاعل");
  }

  return details;
}

/**
 * Analyze content using OpenAI API (if available) or mock analyzer
 */
async function analyzeWithOpenAI(
  content: string,
  contentType: ContentType
): Promise<AnalysisResult> {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  if (!apiKey) throw new Error("API key not configured");

  const SYSTEM_PROMPT = `أنت خبير متخصص في تحليل الاحتيال الإلكتروني باللغة العربية.
حلّل المحتوى وحدد ما إذا كان احتيالاً. استجب بـ JSON فقط:
{
  "riskLevel": "safe" | "caution" | "danger",
  "riskScore": 0-100,
  "threatType": "phishing" | "prize_scam" | "investment_fraud" | "identity_theft" | "malicious_link" | "social_engineering" | "suspicious_offer" | "general_spam" | "safe",
  "details": ["علامة تحذير 1", "علامة تحذير 2"],
  "recommendation": "توصية"
}`;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4-turbo",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          {
            role: "user",
            content: `حلّل هذا/${contentType === "message" ? "رسالة" : contentType === "email" ? "بريد" : "رابط"} للاحتيال:\n\n${content}`,
          },
        ],
        temperature: 0.3,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`OpenAI error: ${error.error?.message || "Unknown error"}`);
    }

    const data = await response.json();
    const text = data.choices?.[0]?.message?.content || "{}";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    const analysis = JSON.parse(jsonMatch?.[0] || "{}");

    return {
      riskLevel: (analysis.riskLevel || "safe") as RiskLevel,
      riskScore: Math.round(analysis.riskScore || 0),
      threatType: analysis.threatType || "safe",
      details: analysis.details || [],
      recommendation: analysis.recommendation || "يرجى توخي الحذر",
      showKullunAmn: analysis.riskLevel === "danger",
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw error;
  }
}

export async function analyzeContent(
  content: string,
  contentType: ContentType
): Promise<AnalysisResult> {
  // Try to use real OpenAI API if key is available
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  if (apiKey && apiKey.startsWith("sk-")) {
    try {
      return await analyzeWithOpenAI(content, contentType);
    } catch (error) {
      console.warn("OpenAI API failed, falling back to mock analyzer:", error);
      // Fall back to mock analyzer if API fails
    }
  }

  // Mock analyzer fallback
  // Simulate AI processing delay
  await new Promise((resolve) => setTimeout(resolve, 2200 + Math.random() * 800));

  if (!content.trim()) {
    return {
      riskLevel: "safe",
      riskScore: 0,
      threatType: "safe",
      details: ["لم يتم إدخال أي محتوى للتحليل"],
      recommendation: "الرجاء إدخال المحتوى المراد تحليله",
      showKullunAmn: false,
    };
  }

  const dangerMatches = DANGER_PATTERNS.filter((p) => p.test(content)).length;
  const cautionMatches = CAUTION_PATTERNS.filter((p) => p.test(content)).length;

  let riskScore: number;
  let riskLevel: RiskLevel;

  if (dangerMatches >= 2) {
    riskScore = Math.min(95, 65 + dangerMatches * 8 + Math.random() * 10);
    riskLevel = "danger";
  } else if (dangerMatches === 1) {
    riskScore = 45 + Math.random() * 25;
    riskLevel = riskScore >= 60 ? "danger" : "caution";
  } else if (cautionMatches >= 1) {
    riskScore = 20 + cautionMatches * 10 + Math.random() * 15;
    riskLevel = "caution";
  } else {
    riskScore = Math.random() * 18;
    riskLevel = "safe";
  }

  riskScore = Math.round(riskScore);

  const threatType = detectThreatType(content, contentType);
  const details = generateDetails(content, contentType, riskLevel, threatType);

  const recommendations: Record<RiskLevel, string> = {
    danger: "تحذير شديد: لا تتفاعل مع هذا المحتوى أو تشارك أي معلومات شخصية. احذف الرسالة فوراً.",
    caution: "تنبيه: كن حذراً عند التعامل مع هذا المحتوى. تحقق من المصدر قبل اتخاذ أي إجراء.",
    safe: "يبدو المحتوى آمناً، لكن دائماً كن يقظاً عند التعامل مع الرسائل غير المتوقعة.",
  };

  return {
    riskLevel,
    riskScore,
    threatType,
    details,
    recommendation: recommendations[riskLevel],
    showKullunAmn: riskLevel === "danger",
  };
}
