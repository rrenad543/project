/**
 * HeroSection — خلك نبيه
 * Vigilant Clarity: asymmetric layout, amber headline, shield watermark, dark navy
 */
import { Shield, ArrowLeft, AlertTriangle } from "lucide-react";

export default function HeroSection() {
  const scrollToAnalyzer = () => {
    document.getElementById("analyzer")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{
        background: "linear-gradient(135deg, oklch(0.14 0.04 255) 0%, oklch(0.18 0.04 255) 50%, oklch(0.20 0.05 260) 100%)",
      }}
    >
      {/* Background image */}
      <div
        className="absolute inset-0 opacity-40"
        style={{
          backgroundImage: "url(/manus-storage/hero-bg_33e021db.png)",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[oklch(0.14_0.04_255/0.3)] via-transparent to-[oklch(0.14_0.04_255/0.8)]" />

      {/* Animated particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-[oklch(0.78_0.16_75/0.4)] rounded-full animate-pulse"
            style={{
              top: `${15 + i * 14}%`,
              left: `${8 + i * 13}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${2 + i * 0.5}s`,
            }}
          />
        ))}
      </div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Right column — text (RTL: this is the primary content) */}
          <div className="order-1">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[oklch(0.78_0.16_75/0.12)] border border-[oklch(0.78_0.16_75/0.3)] text-[oklch(0.88_0.12_80)] text-sm font-medium mb-6">
              <div className="w-1.5 h-1.5 bg-[oklch(0.78_0.16_75)] rounded-full animate-pulse" />
              <span>مدعوم بالذكاء الاصطناعي</span>
            </div>

            {/* Main headline */}
            <h1
              className="text-4xl md:text-5xl lg:text-6xl font-black text-white leading-tight mb-6"
              style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
            >
              لا تقع في{" "}
              <span className="text-[oklch(0.78_0.16_75)] relative">
                الفخ
                <span className="absolute -bottom-1 right-0 left-0 h-0.5 bg-[oklch(0.78_0.16_75/0.4)] rounded-full" />
              </span>
              <br />
              <span className="text-[oklch(0.88_0.12_80)]">خلك نبيه</span>
            </h1>

            {/* Subheadline */}
            <p className="text-lg text-white/65 leading-relaxed mb-8 max-w-lg">
              منصة ذكية تحلل الرسائل والبريد الإلكتروني والروابط المشبوهة وتكشف محاولات الاحتيال الإلكتروني قبل فوات الأوان.
            </p>

            {/* CTA buttons */}
            <div className="flex flex-wrap gap-3">
              <button
                onClick={scrollToAnalyzer}
                className="flex items-center gap-2.5 px-7 py-3.5 bg-[oklch(0.78_0.16_75)] text-[oklch(0.14_0.04_255)] rounded-xl font-black text-base hover:bg-[oklch(0.84_0.14_75)] active:scale-[0.97] transition-all duration-200 shadow-lg shadow-[oklch(0.78_0.16_75/0.3)]"
                style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
              >
                <Shield size={18} />
                <span>ابدأ التحليل مجاناً</span>
                <ArrowLeft size={16} />
              </button>
              <button
                onClick={() => document.getElementById("how-it-works")?.scrollIntoView({ behavior: "smooth" })}
                className="flex items-center gap-2 px-6 py-3.5 bg-white/8 border border-white/15 text-white/80 rounded-xl font-medium text-base hover:bg-white/12 hover:text-white active:scale-[0.97] transition-all duration-200"
              >
                <span>كيف يعمل؟</span>
              </button>
            </div>

            {/* Trust indicators */}
            <div className="flex flex-wrap items-center gap-5 mt-8 pt-8 border-t border-white/10">
              {[
                { value: "+٢٠٠٠", label: "تحليل يومياً" },
                { value: "٩٧٪", label: "دقة الكشف" },
                { value: "مجاني", label: "بالكامل" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <p
                    className="text-xl font-black text-[oklch(0.78_0.16_75)]"
                    style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}
                  >
                    {stat.value}
                  </p>
                  <p className="text-xs text-white/45">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Left column — illustration */}
          <div className="order-2 flex justify-center lg:justify-start">
            <div className="relative">
              {/* Glow ring */}
              <div className="absolute inset-0 rounded-3xl bg-[oklch(0.78_0.16_75/0.08)] blur-2xl scale-110" />

              {/* Main illustration card */}
              <div className="relative bg-[oklch(0.22_0.045_255/0.9)] border border-white/10 rounded-3xl overflow-hidden shadow-2xl shadow-black/50 backdrop-blur-sm max-w-sm">
                <div className="h-1 bg-gradient-to-l from-[oklch(0.78_0.16_75)] via-[oklch(0.88_0.12_80)] to-transparent" />
                <img
                  src="/manus-storage/analysis-illustration_37d9a6dd.png"
                  alt="تحليل الاحتيال"
                  className="w-full object-cover"
                />
                {/* Overlay badge */}
                <div className="absolute bottom-4 right-4 left-4">
                  <div className="bg-[oklch(0.62_0.22_25/0.9)] backdrop-blur-sm border border-[oklch(0.72_0.22_25/0.5)] rounded-xl p-3 flex items-center gap-3">
                    <AlertTriangle size={18} className="text-[oklch(0.82_0.18_25)] shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-white" style={{ fontFamily: "'Noto Kufi Arabic', sans-serif" }}>
                        تم اكتشاف محاولة احتيال!
                      </p>
                      <p className="text-[10px] text-white/70">نسبة الخطر: ٨٩٪ — احتيال جوائز وهمية</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path d="M0 60L60 50C120 40 240 20 360 15C480 10 600 20 720 25C840 30 960 30 1080 25C1200 20 1320 10 1380 5L1440 0V60H0Z" fill="oklch(0.18 0.04 255)" />
        </svg>
      </div>
    </section>
  );
}
